import random
import math
import matplotlib.pyplot as plt
import matplotlib as mpl
import numpy as np
from cvxopt import matrix, solvers
import copy
import time

# Handwriting, from Homework 6
def extract_data(filename):
  data = []
  with open(filename) as f:
    for line in f:
      cols = line.split()
      if len(cols) < 256: # Bad data
        continue
      digit = int(float(cols[0]))
      # However, we need to set 1 to +1 and others as -1
      data.append((1 if digit == 1 else -1, np.reshape([float(pixel) for pixel in cols[1:]], (-1, 16))))
  return data

trainData = extract_data('./ZipDigits.train')
testData = extract_data('./ZipDigits.test')
allData = trainData + testData

def symmetry(image):
  res = 0.0

  for i in range(8):
      for j in range(16):
          res += abs(image[i][j]-image[15-i][j])
  return res / 256

def intensity(image):
  return np.sum(image) / 256

intensityData = [(y, intensity(x)) for (y, x) in allData]
symmetryData = [(y, symmetry(x)) for (y, x) in allData]

# Make max to 1 and min to -1
def normalize(data, x_max_target=1.0, x_min_target=-1.0):
  x = [x for (y, x) in data]
  x_max = max(x)
  x_min = min(x)
  # scale is to make it the same range(clac distance) as the target
  x_scale = float(x_max_target - x_min_target) / float(x_max - x_min)
  # shift is to align the target, by calculate mid points and align them
  # min + (max - min) / 2 = min + max / 2 - min / 2 = (min + max) / 2
  x_shift = float(x_min_target + x_max_target) / 2 - float(x_max + x_min) / 2

  sc = lambda x1: (x1 + x_shift) * x_scale

  normalized_data = [(y, sc(x)) for (y, x) in data]

  return normalized_data

normalizedIntensityData = normalize(intensityData)
normalizedSymmetryData = normalize(symmetryData)

# From Homework 9
# Random 300 data
def randomTrainTestData(*features,train_num=300):
  data = []
  for i in range(len(features[0])):
    ls = []
    for j in range(len(features)):
      ls.append(features[j][i][1])
    data.append((features[j][i][0], tuple(ls)))

  random.shuffle(data)
  train = data[:train_num]
  test = data[train_num:]

  return train, test

# Shared values
train, test = randomTrainTestData(normalizedIntensityData, normalizedSymmetryData)
xmin = min([x[0] for _, x in train])-0.1
xmax = max([x[0] for _, x in train])+0.1
ymin = min([x[1] for _, x in train])-0.1
ymax = max([x[1] for _, x in train])+0.1



import numpy as np
import matplotlib.pyplot as plt
import copy

# -----------------------
# Activation Functions
# -----------------------
def tanh(z):
    return np.tanh(z)

def dtanh(z):
    # derivative of tanh(z) = 1 - tanh(z)^2
    return 1.0 - np.tanh(z)**2

# -----------------------
# Forward Pass
# -----------------------
def forward_pass(X, W1, W2):
    """
    X: input data (N,2)
    W1: (10, 3) - includes bias
    W2: (1, 11) - includes bias
    Returns:
      h: hidden activations (N,10)
      y_hat: output predictions (N,1)
      z1: pre-activation hidden
      z2: pre-activation output
    """
    N = X.shape[0]
    # Add bias to X
    X_b = np.concatenate([X, np.ones((N,1))], axis=1) # (N,3)
    z1 = X_b @ W1.T # (N,10)
    h = tanh(z1)
    h_b = np.concatenate([h, np.ones((N,1))], axis=1) # (N,11)
    z2 = h_b @ W2.T # (N,1)
    y_hat = z2 # linear output during training
    return h, y_hat, z1, z2

# -----------------------
# Error Function
# -----------------------
def compute_error(y_hat, y):
    # E_in = (1/(4N)) * sum (y_hat - y)^2
    N = y.shape[0]
    return (1/(4.0*N))*np.sum((y_hat - y)**2)

# -----------------------
# Gradients (Backprop)
# -----------------------
def compute_gradients(X, y, W1, W2, lambda_reg=0.0):
    """
    Backpropagation to compute gradients.
    """
    N = X.shape[0]
    h, y_hat, z1, z2 = forward_pass(X, W1, W2)
    # dE/dy_hat = (y_hat - y)/(2N)
    dE_dy_hat = (y_hat - y)/(2.0*N)
    # Output layer is linear, so dE/dz2 = dE/dy_hat
    dE_dz2 = dE_dy_hat

    # Hidden layer
    W2_no_bias = W2[:,:-1] # (1,10)
    dE_dh = dE_dz2 @ W2_no_bias
    dE_dz1 = dE_dh * dtanh(z1)

    # Gradients for W2:
    h_b = np.concatenate([h, np.ones((N,1))], axis=1)
    dE_dW2 = dE_dz2.T @ h_b # (1,11)

    # Gradients for W1:
    X_b = np.concatenate([X, np.ones((N,1))], axis=1) # (N,3)
    dE_dW1 = dE_dz1.T @ X_b # (10,3)

    # Add weight decay:
    if lambda_reg > 0:
        dE_dW1 += lambda_reg * W1
        dE_dW2 += lambda_reg * W2

    return dE_dW1, dE_dW2

# -----------------------
# Classification
# -----------------------
def classify(X, W1, W2):
    _, y_hat, _, _ = forward_pass(X, W1, W2)
    # After training, use sign for classification
    return np.sign(y_hat).flatten()

# -----------------------
# Plot Decision Boundary
# -----------------------
def plot_classifier(W1, W2, xmin, xmax, ymin, ymax, title, train, test):
    # Create a grid
    xx, yy = np.meshgrid(np.linspace(xmin, xmax, 200),
                         np.linspace(ymin, ymax, 200))
    Xgrid = np.column_stack((xx.ravel(), yy.ravel()))
    preds = classify(Xgrid, W1, W2)
    preds = preds.reshape(xx.shape)

    plt.figure(figsize=(8,6))
    plt.contourf(xx, yy, preds, levels=[-1,0,1], alpha=0.5, cmap='coolwarm')
    # Plot training points
    for label, marker, c in [(1, 'o', 'blue'), (-1, 'x', 'red')]:
        subset = [(x,y) for (l,(x,y)) in train if l==label]
        subset = np.array(subset)
        if len(subset)>0:
            plt.scatter(subset[:,0], subset[:,1], marker=marker, c=c, label='Train '+str(label))
    # Plot test points
    subset_p = [(x,y) for (l,(x,y)) in test if l==1]
    subset_n = [(x,y) for (l,(x,y)) in test if l==-1]
    if len(subset_p)>0:
        subset_p = np.array(subset_p)
        plt.scatter(subset_p[:,0], subset_p[:,1], facecolors='none', edgecolors='blue', s=80, label='Test +1')
    if len(subset_n)>0:
        subset_n = np.array(subset_n)
        plt.scatter(subset_n[:,0], subset_n[:,1], facecolors='none', edgecolors='red', s=80, label='Test -1')

    plt.title(title)
    plt.legend()
    plt.xlabel('Feature 1')
    plt.ylabel('Feature 2')
    plt.savefig(f'{title}.png')
    plt.show()

# -----------------------
# Variable Learning Rate Gradient Descent (Batch)
# -----------------------
def variable_learning_rate_gradient_descent(X, y, W1, W2, lambda_reg=0.0, max_iter=2000000, initial_lr=0.1,
                                            error_check_interval=10000, early_stopping=False,
                                            X_val=None, y_val=None):
    lr = initial_lr
    prev_error = float('inf')
    best_W1 = copy.deepcopy(W1)
    best_W2 = copy.deepcopy(W2)
    best_val_error = float('inf')
    errors = []
    patience = 50000
    no_improve_iters = 0

    i = 0
    while i < max_iter:
        dW1, dW2 = compute_gradients(X, y, W1, W2, lambda_reg)
        # Try update
        W1_try = W1 - lr * dW1
        W2_try = W2 - lr * dW2

        _, y_hat_try, _, _ = forward_pass(X, W1_try, W2_try)
        error_try = compute_error(y_hat_try, y)

        if error_try <= prev_error:
            # Accept update
            W1, W2 = W1_try, W2_try
            prev_error = error_try
            # Occasionally increase learning rate slightly
            if i % (10*error_check_interval) == 0 and i>0:
                lr *= 1.05
            no_improve_iters = 0
        else:
            # Reject update, reduce LR
            lr *= 0.5
            no_improve_iters += 1

        # Early stopping check or record error
        if i % error_check_interval == 0:
            if early_stopping and X_val is not None and y_val is not None:
                _, y_hat_val, _, _ = forward_pass(X_val, W1, W2)
                val_error = compute_error(y_hat_val, y_val)
                if val_error < best_val_error:
                    best_val_error = val_error
                    best_W1 = copy.deepcopy(W1)
                    best_W2 = copy.deepcopy(W2)
                    no_improve_iters = 0
                else:
                    no_improve_iters += error_check_interval
                    if no_improve_iters > patience:
                        # Early stopping trigger
                        break
            errors.append(prev_error)
        i += 1

    if early_stopping and X_val is not None and y_val is not None:
        return best_W1, best_W2, errors
    else:
        return W1, W2, errors

# -----------------------
# Stochastic Gradient Descent
# -----------------------


def stochastic_gradient_descent(X, y, W1, W2, lambda_reg=0.0, max_iter=20000000, initial_lr=0.1,
                                error_check_interval=10000, early_stopping=False,
                                X_val=None, y_val=None):
    """
    Stochastic Gradient Descent with optional early stopping:
    - Uses single-sample updates (true SGD).
    - Records and optionally checks validation error periodically.
    - Stops early if validation error does not improve for 'patience' checks.
    """
    N = X.shape[0]
    lr = initial_lr
    prev_error = float('inf')
    errors = []

    # Early stopping variables
    best_W1 = copy.deepcopy(W1)
    best_W2 = copy.deepcopy(W2)
    best_val_error = float('inf')
    patience = 50000
    no_improve_iters = 0

    for i in range(max_iter):
        # Pick a random sample
        idx = np.random.randint(N)
        X_i = X[idx:idx+1,:]
        y_i = y[idx:idx+1,:]

        # Compute gradients for the single example
        dW1, dW2 = compute_gradients(X_i, y_i, W1, W2, lambda_reg)

        # Update weights
        W1 -= lr * dW1
        W2 -= lr * dW2

        # Every error_check_interval iterations, check errors
        if (i+1) % error_check_interval == 0:
            # Compute training error on full dataset
            _, y_hat_full, _, _ = forward_pass(X, W1, W2)
            current_error = compute_error(y_hat_full, y)
            errors.append(current_error)

            # Check for early stopping if enabled
            if early_stopping and X_val is not None and y_val is not None:
                _, y_hat_val, _, _ = forward_pass(X_val, W1, W2)
                val_error = compute_error(y_hat_val, y_val)
                if val_error < best_val_error:
                    best_val_error = val_error
                    best_W1 = copy.deepcopy(W1)
                    best_W2 = copy.deepcopy(W2)
                    no_improve_iters = 0
                else:
                    no_improve_iters += error_check_interval
                    if no_improve_iters > patience:
                        # Early stopping trigger
                        break

    if early_stopping and X_val is not None and y_val is not None:
        return best_W1, best_W2, errors
    else:
        return W1, W2, errors

# -----------------------
# Main demonstration code
# -----------------------
if __name__ == "__main__":
    # Assuming you have train, test data and xmin, xmax, ymin, ymax defined.
    # train, test = ...
    # xmin, xmax, ymin, ymax = ...
    mi=2000000
    intv=10

    data_train = train
    data_test = test
    X_train = np.array([x for (l,x) in data_train])
    y_train = np.array([l for (l,x) in data_train]).reshape(-1,1)
    N = X_train.shape[0]  # Should be 300


 

    # -----------------------
    # (a) Variable Learning Rate GD
    # -----------------------
    # m=10 hidden units
    np.random.seed(42)
    W1 = np.random.randn(10,3)*0.01
    W2 = np.random.randn(1,11)*0.01
    # 2×10^6 iterations
    W1_a, W2_a, errors_a = variable_learning_rate_gradient_descent(
        X_train, y_train, W1, W2, lambda_reg=0.0, max_iter=mi, initial_lr=0.1,
        error_check_interval=intv, early_stopping=False
    )

    iterations_a = (np.arange(len(errors_a)) + 1)*intv
    plt.figure()
    plt.semilogx(iterations_a, errors_a)
    plt.xlabel('Iteration')
    plt.ylabel('E_in(w)')
    plt.title('Part (a): E_in vs iteration (Variable LR GD)')
    plt.savefig('part_a_GD.png')
    plt.show()

    plot_classifier(W1_a, W2_a, xmin, xmax, ymin, ymax, 'Part (a) Classifier', train, test)

    # -----------------------
    # (b) Stochastic Gradient Descent
    # -----------------------
    # 2×10^7 iterations and we will plot E_in vs iteration/N to represent epochs
    np.random.seed(42)
    W1 = np.random.randn(10,3)*0.01
    W2 = np.random.randn(1,11)*0.01
    max_iter_b = mi*10
    error_check_interval_b = intv  # check error every 1,000,000 iters
    W1_b, W2_b, errors_b = stochastic_gradient_descent(
        X_train, y_train, W1, W2, lambda_reg=0.0, max_iter=max_iter_b, initial_lr=0.1,
        error_check_interval=error_check_interval_b
    )

    # iterations in terms of epochs = iteration / N
    epochs_b = (np.arange(len(errors_b))+1)* (error_check_interval_b / N)
    plt.figure()
    plt.semilogx(epochs_b, errors_b)
    plt.xlabel('Epoch (iteration/N)')
    plt.ylabel('E_in(w)')
    plt.title('Part (b): E_in vs iteration/N (SGD)')
    plt.savefig('part_b_SGD.png')
    plt.show()

    plot_classifier(W1_b, W2_b, xmin, xmax, ymin, ymax, 'Part (b) Classifier (SGD)', train, test)
    # Explanation: We divide iteration by N to represent progress in terms of full passes through data (epochs).

    # -----------------------
    # (c) With Weight Decay (lambda=0.01/N)
    # Repeat (a) or (b) scenario, here we do (a) with weight decay
    # -----------------------
    lambda_reg = 0.01/N
    np.random.seed(42)
    W1 = np.random.randn(10,3)*0.01
    W2 = np.random.randn(1,11)*0.01
    W1_c, W2_c, errors_c = variable_learning_rate_gradient_descent(
        X_train, y_train, W1, W2, lambda_reg=lambda_reg, max_iter=mi, initial_lr=0.1,
        error_check_interval=intv, early_stopping=False
    )

    iterations_c = (np.arange(len(errors_c)) + 1)*intv
    plt.figure()
    plt.semilogx(iterations_c, errors_c)
    plt.xlabel('Iteration')
    plt.ylabel('E_in(w) + weight decay')
    plt.title('Part (c): E_in + weight decay vs iteration (Variable LR GD)')
    plt.savefig('part_c_GD.png')
    plt.show()

    plot_classifier(W1_c, W2_c, xmin, xmax, ymin, ymax, 'Part (c) Classifier with Weight Decay', train, test)
    
    # -----------------------
    # (c) With Weight Decay (lambda=0.01/N)
    # Repeat (a) or (b) scenario, here we do (b) with weight decay
    # -----------------------
    lambda_reg = 0.01/N
    np.random.seed(42)
    W1 = np.random.randn(10,3)*0.01
    W2 = np.random.randn(1,11)*0.01
    W1_cb, W2_cb, errors_cb = stochastic_gradient_descent(
        X_train, y_train, W1, W2, lambda_reg=lambda_reg, max_iter=mi*10, initial_lr=0.1,
        error_check_interval=intv, early_stopping=False
    )

    iterations_cb = (np.arange(len(errors_cb)) + 1)*intv
    plt.figure()
    plt.semilogx(iterations_cb, errors_cb)
    plt.xlabel('Iteration')
    plt.ylabel('E_in(w) + weight decay')
    plt.title('Part (c): E_in + weight decay vs iteration (SGD)')
    plt.savefig('part_c_SGD.png')
    plt.show()
    
    plot_classifier(W1_cb, W2_cb, xmin, xmax, ymin, ymax, 'Part (c) Classifier with Weight Decay (SGD)', train, test)
    
    # -----------------------
    # (d) Early Stopping...for (a) GD
    # Use 250 points for training and 50 for validation
    # -----------------------
    np.random.shuffle(data_train)
    train_sub = data_train[:250]
    val_sub = data_train[250:]
    X_sub = np.array([x for (l,x) in train_sub])
    y_sub = np.array([l for (l,x) in train_sub]).reshape(-1,1)
    X_val = np.array([x for (l,x) in val_sub])
    y_val = np.array([l for (l,x) in val_sub]).reshape(-1,1)

    np.random.seed(42)
    W1 = np.random.randn(10,3)*0.01
    W2 = np.random.randn(1,11)*0.01
    W1_d, W2_d, errors_d = variable_learning_rate_gradient_descent(
        X_sub, y_sub, W1, W2, lambda_reg=0.0, max_iter=mi, initial_lr=0.1,
        error_check_interval=intv, early_stopping=True, X_val=X_val, y_val=y_val
    )

    iterations_d = (np.arange(len(errors_d)) + 1)*intv
    plt.figure()
    plt.semilogx(iterations_d, errors_d)
    plt.xlabel('Iteration')
    plt.ylabel('E_in(w) on Training Subset')
    plt.title('Part (d): E_in vs iteration with Early Stopping')
    plt.savefig('part_d_early_GD.png')
    plt.show()

    # Show the classifier from early stopping
    plot_classifier(W1_d, W2_d, xmin, xmax, ymin, ymax, 'Part (d) Classifier with Early Stopping', train_sub, val_sub)
    
    # -----------------------
    # (d) Early Stopping...for (b) SGD
    # Use 250 points for training and 50 for validation
    # -----------------------
    # -----------------------

    np.random.seed(42)
    W1 = np.random.randn(10,3)*0.01
    W2 = np.random.randn(1,11)*0.01
    W1_db, W2_db, errors_db = stochastic_gradient_descent(
        X_train, y_train, W1, W2, lambda_reg=0, max_iter=mi*10, initial_lr=0.1,
        error_check_interval=intv, early_stopping=True
    )

    iterations_db = (np.arange(len(errors_db)) + 1)*intv
    plt.figure()
    plt.semilogx(iterations_db, errors_db)
    plt.xlabel('Iteration')
    plt.ylabel('E_in(w)')
    plt.title('Part (d): E_in y vs iteration (SGD) with Early Stopping')
    plt.savefig('part_d_early_SGD.png')
    plt.show()
    
    plot_classifier(W1_cb, W2_cb, xmin, xmax, ymin, ymax, 'Part (d) Classifier with Early stopping (SGD)', train, test)

    # After training in all parts, you now use sign at the output layer for classification (already implemented in classify()).

